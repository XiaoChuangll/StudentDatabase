import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;


public class StudentDatabaseGUI extends JFrame {

    private StudentDatabase database;
    private JTextField keywordField;
    private JTextField fieldField;
    private JTextArea outputTextArea;

    public StudentDatabaseGUI() {
        this.database = new StudentDatabase();

        setTitle("学生数据库管理系统");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 创建组件
        keywordField = new JTextField();
        fieldField = new JTextField();
        outputTextArea = new JTextArea();
// 在构造函数或初始化方法中
        outputTextArea.setEditable(false);
        JButton queryButton = new JButton("查询学生信息");
        JButton sortButton = new JButton("排序学生信息");
        JButton addButton = new JButton("添加新学生");
        JButton batchAddButton = new JButton("批量添加新学生");
        JButton deleteButton = new JButton("删除学生");
        JButton updateButton = new JButton("更新学生信息");
        JButton clearButton = new JButton("清屏");
        JButton undoButton = new JButton("撤销");
        // 设置布局
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
        inputPanel.add(new JLabel("关键字:"));
        inputPanel.add(keywordField);
        JComboBox<String> fieldComboBox = new JComboBox<>(new String[]{"姓名", "学号", "班级", "课程"});
        inputPanel.add(new JLabel("查询字段:"));
        inputPanel.add(fieldComboBox);

        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(outputTextArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 2));

        buttonPanel.add(queryButton); // 查询按钮，用于执行学生信息查询操作
        buttonPanel.add(sortButton);  // 排序按钮，用于执行学生信息排序操作
        buttonPanel.add(addButton);   // 添加按钮，用于添加新学生信息
        buttonPanel.add(batchAddButton); // 批量添加按钮，用于从文件批量添加新学生信息
        buttonPanel.add(deleteButton);    // 删除按钮，用于删除学生信息
        buttonPanel.add(updateButton);    // 更新按钮，用于更新学生信息
        buttonPanel.add(clearButton);     // 清屏按钮，用于清空显示区域的内容
        buttonPanel.add(undoButton);      // 撤销按钮，用于撤销最近的操作
        add(buttonPanel, BorderLayout.SOUTH);

        // 添加事件监听器
        // 为查询按钮添加事件监听器
        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = keywordField.getText();
                String field = (String) fieldComboBox.getSelectedItem(); // 获取下拉菜单选项
                List<Student> result = database.queryStudents(keyword, field);
                updateOutput(result);
            }
        });
        // 撤销按钮事件监听器
        undoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                database.undo();
                updateOutput(database.getStudents());
            }
        });
        // 为删除按钮添加事件监听器
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 清空文本区域的内容
                outputTextArea.setText("");
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 显示删除学生对话框
                showDeleteStudentDialog();
            }
        });

// 为更新按钮添加事件监听器
        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = keywordField.getText();
                String field = (String) fieldComboBox.getSelectedItem();
                List<Student> result = database.queryStudents(keyword, field);

                if (!result.isEmpty()) {
                    // 如果查询结果非空，显示查询结果的新窗口
                    showQueryResultDialog(result);
                } else {
                    JOptionPane.showMessageDialog(null, "未找到匹配的学生。");
                }
            }
        });

        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = keywordField.getText();
                String field = fieldField.getText();
                List<Student> result = database.queryStudents(keyword, field);

                updateOutput(result);
            }
        });
        //排序功能
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 创建排序条件的菜单
                String[] sortingOptions = {"单科成绩", "总成绩", "平均成绩", "学号", "优秀率", "不及格率"};
                String selectedOption = (String) JOptionPane.showInputDialog(null,
                        "请选择排序条件:", "选择排序条件", JOptionPane.PLAIN_MESSAGE, null, sortingOptions, sortingOptions[0]);

                if (selectedOption != null && !selectedOption.isEmpty()) {
                    // 根据用户选择的条件进行排序
                    List<Student> sortedStudents = database.sortStudents(selectedOption);
                    updateOutput(sortedStudents);
                } else {
                    JOptionPane.showMessageDialog(null, "请选择有效的排序条件。");
                }
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 显示添加新学生的对话框
                showAddStudentDialog();
            }
        });

        batchAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 执行批量添加新学生的操作
                batchAddStudents();
            }
        });
    }
    private void showQueryResultDialog(List<Student> students) {
        // 创建新的窗口
        JFrame queryResultFrame = new JFrame("查询结果");

        // 设置布局
        queryResultFrame.setLayout(new BorderLayout());

        // 创建文本区域用于显示查询结果
        JTextArea queryResultTextArea = new JTextArea();
        queryResultTextArea.setEditable(false);

        // 添加查询结果到文本区域
        updateOutput(queryResultTextArea, students);

        // 将文本区域添加到滚动面板
        JScrollPane scrollPane = new JScrollPane(queryResultTextArea);

        // 添加滚动面板到窗口中
        queryResultFrame.add(scrollPane, BorderLayout.CENTER);
        

        // 创建“修改”按钮
        JButton modifyButton = new JButton("修改学生信息");
        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 获取选定学生的索引
                int selectedIndex = queryResultTextArea.getCaretPosition();

                // 确保选中的位置有效
                if (selectedIndex >= 0 && selectedIndex < students.size()) {
                    // 获取选中的学生对象
                    Student selectedStudent = students.get(selectedIndex);

                    // 显示更新学生信息的对话框
                    showUpdateStudentDialog(selectedStudent);
                }
            }
        });

        // 添加“修改”按钮到窗口底部
        queryResultFrame.add(modifyButton, BorderLayout.SOUTH);

        // 设置窗口属性
        queryResultFrame.setSize(500, 400);
        queryResultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        queryResultFrame.setVisible(true);
    }

    private void updateOutput(JTextArea queryResultTextArea, List<Student> students) {

    }

    private void showDeleteStudentDialog() {
        JTextField studentIdField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(1, 2));
        panel.add(new JLabel("学号:"));
        panel.add(studentIdField);

        int result = JOptionPane.showConfirmDialog(null, panel, "删除学生", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            // 获取用户输入的学生学号
            String studentIdToDelete = studentIdField.getText();

            // 删除学生
            database.deleteStudent(studentIdToDelete);

            // 更新显示
            updateOutput(database.getStudents());
        }
    }
    private void showUpdateStudentDialog(Student student) {
        // 使用 student 参数初始化文本框
        JTextField studentIdField = new JTextField(student.getStudentId());
        JTextField nameField = new JTextField(student.getName());
        JTextField classNameField = new JTextField(student.getClassName());
        JTextField chineseScoreField = new JTextField(String.valueOf(student.getChineseScore()));
        JTextField mathScoreField = new JTextField(String.valueOf(student.getMathScore()));
        JTextField englishScoreField = new JTextField(String.valueOf(student.getEnglishScore()));

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("学号:"));
        panel.add(studentIdField);
        panel.add(new JLabel("姓名:"));
        panel.add(nameField);
        panel.add(new JLabel("班级:"));
        panel.add(classNameField);
        panel.add(new JLabel("语文成绩:"));
        panel.add(chineseScoreField);
        panel.add(new JLabel("数学成绩:"));
        panel.add(mathScoreField);
        panel.add(new JLabel("英语成绩:"));
        panel.add(englishScoreField);

        int result = JOptionPane.showConfirmDialog(null, panel, "更新学生信息", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            // 获取用户输入的信息
            String studentId = studentIdField.getText();
            String name = nameField.getText();
            String className = classNameField.getText();
            int chineseScore = Integer.parseInt(chineseScoreField.getText());
            int mathScore = Integer.parseInt(mathScoreField.getText());
            int englishScore = Integer.parseInt(englishScoreField.getText());

            // 创建更新后的学生对象
            Student updatedStudent = new Student();
            updatedStudent.setStudentId(studentId);
            updatedStudent.setName(name);
            updatedStudent.setClassName(className);
            updatedStudent.setChineseScore(chineseScore);
            updatedStudent.setMathScore(mathScore);
            updatedStudent.setEnglishScore(englishScore);

            // 更新学生信息
            database.updateStudent(updatedStudent);

            // 更新显示
            updateOutput(database.getStudents());
        }
    }

    private void showAddStudentDialog() {
        JTextField studentIdField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField classNameField = new JTextField();
        JTextField chineseScoreField = new JTextField();
        JTextField mathScoreField = new JTextField();
        JTextField englishScoreField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("学号:"));
        panel.add(studentIdField);
        panel.add(new JLabel("姓名:"));
        panel.add(nameField);
        panel.add(new JLabel("班级:"));
        panel.add(classNameField);
        panel.add(new JLabel("语文成绩:"));
        panel.add(chineseScoreField);
        panel.add(new JLabel("数学成绩:"));
        panel.add(mathScoreField);
        panel.add(new JLabel("英语成绩:"));
        panel.add(englishScoreField);

        int result = JOptionPane.showConfirmDialog(null, panel, "添加新学生", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            // 获取用户输入的信息
            String studentId = studentIdField.getText();
            String name = nameField.getText();
            String className = classNameField.getText();
            int chineseScore = Integer.parseInt(chineseScoreField.getText());
            int mathScore = Integer.parseInt(mathScoreField.getText());
            int englishScore = Integer.parseInt(englishScoreField.getText());

            // 创建新学生对象
            Student newStudent = new Student();
            newStudent.setStudentId(studentId);
            newStudent.setName(name);
            newStudent.setClassName(className);
            newStudent.setChineseScore(chineseScore);
            newStudent.setMathScore(mathScore);
            newStudent.setEnglishScore(englishScore);

            // 插入新学生到数据库
            database.insertStudent(newStudent);
            updateOutput(Collections.singletonList(new Student())); // 传递一个包含新学生的列表
        }
    }

    private void batchAddStudents() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                List<Student> students = readStudentsFromFile(selectedFile);
                database.insertStudents(students);
                updateOutput(Collections.emptyList()); // 传递一个空列表
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "读取文件时出错：" + ex.getMessage());
            }
        }
    }

    private List<Student> readStudentsFromFile(File file) throws IOException {
        List<Student> students = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                Student student = new Student();
                student.setStudentId(parts[0]);
                student.setName(parts[1]);
                student.setClassName(parts[2]);
                student.setChineseScore(Integer.parseInt(parts[3]));
                student.setMathScore(Integer.parseInt(parts[4]));
                student.setEnglishScore(Integer.parseInt(parts[5]));
                students.add(student);
            }
        }
        return students;
    }

    private void updateOutput(List<Student> students) {
        StringBuilder resultBuilder = new StringBuilder("查询结果：\n");
        for (Student student : students) {
            resultBuilder.append(formatStudentInfo(student)).append("\n");
        }
        outputTextArea.append(resultBuilder.toString());
    }

    private String formatStudentInfo(Student student) {
        return student.getStudentId() + "," + student.getName() + "," + student.getClassName() +
                ",语文:" + student.getChineseScore() + ",数学:" + student.getMathScore() +
                ",英语:" + student.getEnglishScore();
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                StudentDatabaseGUI gui = new StudentDatabaseGUI();
                gui.setVisible(true);
            }
        });
    }
}